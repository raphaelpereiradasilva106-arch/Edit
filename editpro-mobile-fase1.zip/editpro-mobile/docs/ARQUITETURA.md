# EditPro Mobile — Arquitetura e plano (Fase 1)

## O que é viável localmente no Android 11+
- **Timeline, projetos, histórico, salvamento/recuperação:** 100% local (Kotlin puro + Room/arquivos).
- **Cortar, dividir, juntar, velocidade, girar, escala, opacidade, texto, áudio, mixagem, fade:** Media3 Transformer + efeitos GL (`Presentation`, `ScaleAndRotateTransformation`, `OverlayEffect`, `SpeedChangeEffect`). Exportação H.264/HEVC por MediaCodec (hardware).
- **Prévia em tempo real:** Media3 ExoPlayer com `setVideoEffects`, resolução adaptativa/proxy.
- **Filtros, brilho/contraste/saturação, vinheta, glitch, RGB, desfoque, nitidez:** shaders GLSL (`GlShaderProgram`) usados igualmente na prévia e na exportação.
- **Keyframes:** modelo próprio; interpolação avaliada por quadro e passada aos efeitos GL.
- **Gravação de narração, formas de onda, legendas SRT/VTT manuais, fontes TTF/OTF do usuário.**

## Exige trabalho extra / bibliotecas adicionais
- **Transições entre clipes:** Media3 não traz catálogo pronto; cada transição é um shader próprio com dois clipes compostos. Fazer por etapas, só publicar a transição quando ela passar nos testes de prévia **e** exportação.
- **Reverter vídeo, velocidade com curvas, congelar quadro, redução de ruído:** possíveis, mas custosos (reversão exige decodificar GOPs e pode precisar de arquivo temporário).
- **Legendas automáticas:** só com mecanismo de fala (ex.: modelo offline como Whisper/Vosk). Módulo opcional, com requisitos de memória declarados.
- **Melhoria por IA (super-resolução):** modelo TFLite/ONNX opcional; só rotular "IA" se for modelo real. Aumentar resolução por interpolação **não** recupera detalhes que não existem no arquivo.

## Inviável ou dependente de serviço externo
- Biblioteca de músicas/efeitos "como a do CapCut": exige licenciamento; só com conteúdo livre/licenciado.
- Garantia de zero travamentos em qualquer aparelho: não é possível; o objetivo é degradar com elegância (proxy, prévia reduzida, avisos).

## Estrutura de módulos (alvo)
`core/model` · `core/editor` (operações puras + histórico) · `core/storage` (projetos) · `media` (importação, miniaturas, proxy) · `playback` (ExoPlayer) · `effects` (shaders) · `audio` · `export` (Transformer + WorkManager/serviço em primeiro plano) · `ui` (Compose).

## Decisões da Fase 1
- Tempo em **microssegundos (Long)**; velocidade em **milésimos inteiros**: sem erro de ponto flutuante.
- Operações da timeline **puras e imutáveis** → desfazer/refazer por snapshots com limite.
- Projetos em **JSON com CRC32, escrita atômica e backup**; Room entra na Fase 2 só como índice/miniaturas, se necessário.
- Sem permissões de armazenamento: mídia via seletor do sistema.

## Estado real da Fase 1
Implementado: modelo, operações (adicionar, mover, dividir, cortar início/fim, excluir), histórico, `ProjectStore`, tela inicial mínima (criar/listar/excluir com confirmação), testes unitários.
**Não compilado nem testado** neste ambiente (sem Gradle/Kotlin). Falta: renomear/duplicar projetos, importação de mídia, tudo das fases 2 a 10.

## Como compilar
1. Android Studio (versão recente), abrir a pasta `editpro-mobile`.
2. Se pedir, gerar o wrapper (`gradle wrapper`) e sincronizar; ajustar versões em `gradle/libs.versions.toml` se necessário.
3. Testes: `./gradlew :app:testDebugUnitTest`. APK: `./gradlew :app:assembleDebug` → `app/build/outputs/apk/debug/`.
