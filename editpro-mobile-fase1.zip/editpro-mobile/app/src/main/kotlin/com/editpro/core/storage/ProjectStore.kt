package com.editpro.core.storage

import com.editpro.core.model.Project
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption.ATOMIC_MOVE
import java.nio.file.StandardCopyOption.REPLACE_EXISTING
import java.util.zip.CRC32

/**
 * Persistência de projetos em arquivos JSON com:
 *  - escrita atômica (arquivo temporário + fsync + rename);
 *  - checksum CRC32 para detectar corrupção;
 *  - cópia .bak da última versão válida, usada na recuperação.
 * Só mexe na pasta do projeto. NUNCA toca nas mídias originais do usuário (guardamos apenas URIs).
 */
class ProjectStore(private val root: File) {

    data class Loaded(val project: Project, val recoveredFromBackup: Boolean)

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun save(project: Project) {
        val dir = dirOf(project.id).also { it.mkdirs() }
        val main = File(dir, MAIN)
        val bak = File(dir, BAK)
        val tmp = File(dir, TMP)

        val body = json.encodeToString(Project.serializer(), project)
        val payload = "${crc(body)}\n$body".toByteArray(Charsets.UTF_8)
        FileOutputStream(tmp).use { it.write(payload); it.flush(); it.fd.sync() }

        // Só promove a cópia atual a backup se ela estiver íntegra (não sobrescreve backup bom com arquivo corrompido).
        if (main.exists() && parse(main) != null) {
            Files.copy(main.toPath(), bak.toPath(), REPLACE_EXISTING)
        }
        Files.move(tmp.toPath(), main.toPath(), ATOMIC_MOVE, REPLACE_EXISTING)
    }

    fun load(id: String): Loaded? {
        val dir = dirOf(id)
        parse(File(dir, MAIN))?.let { return Loaded(it, false) }
        parse(File(dir, BAK))?.let { return Loaded(it, true) }
        return null
    }

    /** Projetos legíveis, do mais recente para o mais antigo. */
    fun list(): List<Project> =
        (root.listFiles { f -> f.isDirectory } ?: emptyArray())
            .mapNotNull { load(it.name)?.project }
            .sortedByDescending { it.updatedAtMs }

    fun delete(id: String) { dirOf(id).deleteRecursively() }

    private fun dirOf(id: String): File {
        require(ID_REGEX.matches(id)) { "ID de projeto inválido" }   // bloqueia path traversal
        return File(root, id)
    }

    private fun parse(file: File): Project? = try {
        if (!file.exists()) null else {
            val text = file.readText(Charsets.UTF_8)
            val nl = text.indexOf('\n')
            if (nl < 0) null else {
                val body = text.substring(nl + 1)
                if (text.substring(0, nl) != crc(body)) null
                else json.decodeFromString(Project.serializer(), body)
            }
        }
    } catch (e: Exception) { null }

    private fun crc(s: String): String =
        CRC32().apply { update(s.toByteArray(Charsets.UTF_8)) }.value.toString(16)

    private companion object {
        const val MAIN = "project.json"
        const val BAK = "project.json.bak"
        const val TMP = "project.json.tmp"
        val ID_REGEX = Regex("^[A-Za-z0-9_-]{1,64}$")
    }
}
