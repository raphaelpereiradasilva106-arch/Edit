package com.editpro.core.editor

import com.editpro.core.model.Clip
import com.editpro.core.model.Timeline
import com.editpro.core.model.Track

/**
 * Operações puras e imutáveis: cada função devolve uma nova Timeline.
 * Isso torna desfazer/refazer trivial e testável sem Android.
 * Regra: clipes de uma mesma trilha não se sobrepõem; camadas sobrepostas = trilhas diferentes.
 */
object TimelineEditor {

    fun addClip(tl: Timeline, trackId: String, clip: Clip): Timeline {
        val track = tl.track(trackId)
        require(!overlaps(track, clip, ignoreId = null)) { "Clipe sobrepõe outro na mesma trilha" }
        return tl.replaceTrack(track.copy(clips = (track.clips + clip).sortedBy { it.startUs }))
    }

    fun delete(tl: Timeline, clipId: String): Timeline {
        val track = tl.trackOf(clipId)
        return tl.replaceTrack(track.copy(clips = track.clips.filterNot { it.id == clipId }))
    }

    fun move(tl: Timeline, clipId: String, newStartUs: Long): Timeline {
        require(newStartUs >= 0) { "Posição negativa" }
        val track = tl.trackOf(clipId)
        val moved = track.clip(clipId).copy(startUs = newStartUs)
        require(!overlaps(track, moved, ignoreId = clipId)) { "Clipe sobrepõe outro na mesma trilha" }
        return tl.replaceTrack(track.copy(clips = track.clips.map { if (it.id == clipId) moved else it }.sortedBy { it.startUs }))
    }

    /** Divide exatamente em atUs. A metade direita começa onde a esquerda termina (sem lacuna nem sobreposição). */
    fun split(tl: Timeline, clipId: String, atUs: Long, newClipId: String): Timeline {
        val track = tl.trackOf(clipId)
        val c = track.clip(clipId)
        require(atUs > c.startUs && atUs < c.endUs) { "Ponto de divisão fora do clipe" }
        val splitSource = c.sourceInUs + (atUs - c.startUs) * c.speedPermille / 1000L
        require(splitSource > c.sourceInUs && splitSource < c.sourceOutUs) { "Divisão geraria clipe vazio" }
        val left = c.copy(sourceOutUs = splitSource)
        val right = c.copy(id = newClipId, startUs = left.endUs, sourceInUs = splitSource)
        val clips = track.clips.flatMap { if (it.id == clipId) listOf(left, right) else listOf(it) }
        return tl.replaceTrack(track.copy(clips = clips))
    }

    /** Move a borda esquerda: encurta (ou estende, se houver mídia) mantendo o conteúdo no mesmo lugar da timeline. */
    fun trimStart(tl: Timeline, clipId: String, newStartUs: Long): Timeline {
        val track = tl.trackOf(clipId)
        val c = track.clip(clipId)
        val newIn = c.sourceInUs + (newStartUs - c.startUs) * c.speedPermille / 1000L
        require(newIn >= 0 && newIn < c.sourceOutUs) { "Corte inválido" }
        val trimmed = c.copy(startUs = newStartUs, sourceInUs = newIn)
        require(!overlaps(track, trimmed, ignoreId = clipId)) { "Clipe sobrepõe outro na mesma trilha" }
        return tl.replaceTrack(track.copy(clips = track.clips.map { if (it.id == clipId) trimmed else it }))
    }

    /** Move a borda direita. O limite máximo (duração da mídia) deve ser validado por quem chama, com o MediaRef. */
    fun trimEnd(tl: Timeline, clipId: String, newEndUs: Long): Timeline {
        val track = tl.trackOf(clipId)
        val c = track.clip(clipId)
        val newOut = c.sourceInUs + (newEndUs - c.startUs) * c.speedPermille / 1000L
        require(newOut > c.sourceInUs) { "Corte inválido" }
        val trimmed = c.copy(sourceOutUs = newOut)
        require(!overlaps(track, trimmed, ignoreId = clipId)) { "Clipe sobrepõe outro na mesma trilha" }
        return tl.replaceTrack(track.copy(clips = track.clips.map { if (it.id == clipId) trimmed else it }))
    }

    // ---- auxiliares ----
    private fun overlaps(track: Track, c: Clip, ignoreId: String?): Boolean =
        track.clips.any { it.id != ignoreId && c.startUs < it.endUs && it.startUs < c.endUs }

    private fun Timeline.track(id: String) =
        tracks.firstOrNull { it.id == id } ?: throw IllegalArgumentException("Trilha não encontrada: $id")

    private fun Timeline.trackOf(clipId: String) =
        tracks.firstOrNull { t -> t.clips.any { it.id == clipId } }
            ?: throw IllegalArgumentException("Clipe não encontrado: $clipId")

    private fun Track.clip(id: String) = clips.first { it.id == id }

    private fun Timeline.replaceTrack(t: Track) = copy(tracks = tracks.map { if (it.id == t.id) t else it })
}
