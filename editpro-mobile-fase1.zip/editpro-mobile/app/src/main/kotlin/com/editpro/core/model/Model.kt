package com.editpro.core.model

import kotlinx.serialization.Serializable

/**
 * Todo o tempo do modelo é em MICROSSEGUNDOS (Long), a mesma unidade do Media3.
 * Sem Float/Double para posições: evita deriva de sincronização por arredondamento.
 * Velocidade é inteira em milésimos (1000 = 1x) pelo mesmo motivo.
 */
@Serializable
enum class TrackType { VIDEO, AUDIO, TEXT, OVERLAY }

@Serializable
data class MediaRef(
    val id: String,
    val uri: String,            // URI do seletor do sistema; o arquivo original nunca é copiado nem alterado
    val displayName: String,
    val durationUs: Long,
    val hasVideo: Boolean,
    val hasAudio: Boolean,
)

@Serializable
data class Clip(
    val id: String,
    val mediaId: String,
    val startUs: Long,          // posição na timeline
    val sourceInUs: Long,       // trecho usado do arquivo de origem
    val sourceOutUs: Long,
    val speedPermille: Int = 1000,
) {
    init {
        require(startUs >= 0) { "startUs negativo" }
        require(sourceOutUs > sourceInUs) { "clipe vazio" }
        require(speedPermille > 0) { "velocidade inválida" }
    }

    val durationUs: Long get() = (sourceOutUs - sourceInUs) * 1000L / speedPermille
    val endUs: Long get() = startUs + durationUs
}

@Serializable
data class Track(
    val id: String,
    val type: TrackType,
    val clips: List<Clip> = emptyList(),
)

@Serializable
data class Timeline(val tracks: List<Track> = emptyList()) {
    val durationUs: Long get() = tracks.maxOfOrNull { t -> t.clips.maxOfOrNull { it.endUs } ?: 0L } ?: 0L
}

@Serializable
data class Project(
    val id: String,
    val name: String,
    val createdAtMs: Long,
    val updatedAtMs: Long,
    val media: List<MediaRef> = emptyList(),
    val timeline: Timeline = Timeline(),
    val schemaVersion: Int = 1,
)
