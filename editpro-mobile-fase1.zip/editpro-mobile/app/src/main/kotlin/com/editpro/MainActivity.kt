package com.editpro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.editpro.core.model.Project
import com.editpro.core.storage.ProjectStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = ProjectStore(File(filesDir, "projects"))
        setContent { MaterialTheme { HomeScreen(store) } }
    }
}

@Composable
private fun HomeScreen(store: ProjectStore) {
    val scope = rememberCoroutineScope()
    var projects by remember { mutableStateOf(emptyList<Project>()) }
    var toDelete by remember { mutableStateOf<Project?>(null) }

    suspend fun refresh() { projects = withContext(Dispatchers.IO) { store.list() } }
    LaunchedEffect(Unit) { refresh() }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = {
                scope.launch {
                    withContext(Dispatchers.IO) {
                        val now = System.currentTimeMillis()
                        store.save(Project(UUID.randomUUID().toString(), "Projeto ${projects.size + 1}", now, now))
                    }
                    refresh()
                }
            }) { Text("Novo projeto") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            Text("EditPro Mobile", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(12.dp))
            if (projects.isEmpty()) Text("Nenhum projeto ainda. Toque em \"Novo projeto\".")
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(projects, key = { it.id }) { p ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, style = MaterialTheme.typography.titleMedium)
                                Text(DateFormat.getDateTimeInstance().format(Date(p.updatedAtMs)),
                                    style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton(onClick = { toDelete = p }) { Text("Excluir") }
                        }
                    }
                }
            }
        }
    }

    toDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Excluir projeto?") },
            text = { Text("\"${p.name}\" será removido. Os vídeos originais não são apagados.") },
            confirmButton = {
                TextButton(onClick = {
                    toDelete = null
                    scope.launch { withContext(Dispatchers.IO) { store.delete(p.id) }; refresh() }
                }) { Text("Excluir") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } },
        )
    }
}
