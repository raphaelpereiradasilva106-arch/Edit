package com.editpro.core

import com.editpro.core.editor.History
import com.editpro.core.editor.TimelineEditor
import com.editpro.core.model.*
import org.junit.Assert.*
import org.junit.Test

class TimelineEditorTest {
    private fun tl(vararg clips: Clip) = Timeline(listOf(Track("v1", TrackType.VIDEO, clips.toList())))
    private fun clip(id: String, start: Long, len: Long, speed: Int = 1000) =
        Clip(id, "m1", start, 0, len * speed / 1000, speed)

    @Test fun split_keeps_total_duration_and_contiguity() {
        val out = TimelineEditor.split(tl(clip("a", 0, 10_000_000)), "a", 4_000_000, "b")
        val (l, r) = out.tracks[0].clips
        assertEquals(4_000_000, l.durationUs)
        assertEquals(l.endUs, r.startUs)
        assertEquals(10_000_000, r.endUs)
        assertEquals(l.sourceOutUs, r.sourceInUs)
    }

    @Test fun split_with_speed_uses_source_time_correctly() {
        val out = TimelineEditor.split(tl(clip("a", 0, 10_000_000, speed = 2000)), "a", 5_000_000, "b")
        val (l, r) = out.tracks[0].clips
        assertEquals(10_000_000, l.sourceOutUs)      // 5 s de timeline a 2x = 10 s de fonte
        assertEquals(l.sourceOutUs, r.sourceInUs)
    }

    @Test fun split_on_edge_is_rejected() {
        assertThrows(IllegalArgumentException::class.java) {
            TimelineEditor.split(tl(clip("a", 0, 10_000_000)), "a", 0, "b")
        }
    }

    @Test fun trim_start_moves_source_in() {
        val out = TimelineEditor.trimStart(tl(clip("a", 1_000_000, 10_000_000)), "a", 3_000_000)
        val c = out.tracks[0].clips[0]
        assertEquals(2_000_000, c.sourceInUs)
        assertEquals(11_000_000, c.endUs)             // borda direita não se mexe
    }

    @Test fun move_into_other_clip_is_rejected() {
        val t = tl(clip("a", 0, 5_000_000), clip("b", 6_000_000, 5_000_000))
        assertThrows(IllegalArgumentException::class.java) { TimelineEditor.move(t, "b", 4_000_000) }
    }

    @Test fun history_undo_redo_and_limit() {
        val h = History(0, limit = 3)
        (1..5).forEach { h.push(it) }
        assertEquals(5, h.current)
        assertEquals(4, h.undo()); assertEquals(3, h.undo()); assertEquals(2, h.undo())
        assertFalse(h.canUndo)                         // limite de 3 descartou 0 e 1
        assertEquals(3, h.redo())
        h.push(99)
        assertFalse(h.canRedo)
    }
}
