package com.editpro.core

import com.editpro.core.model.Project
import com.editpro.core.storage.ProjectStore
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class ProjectStoreTest {
    @get:Rule val tmp = TemporaryFolder()
    private fun p(name: String, t: Long) = Project("p1", name, 1, t)

    @Test fun roundtrip() {
        val s = ProjectStore(tmp.newFolder())
        s.save(p("A", 1))
        val l = s.load("p1")!!
        assertEquals("A", l.project.name); assertFalse(l.recoveredFromBackup)
    }

    @Test fun corrupted_main_recovers_from_backup() {
        val root = tmp.newFolder(); val s = ProjectStore(root)
        s.save(p("v1", 1)); s.save(p("v2", 2))
        File(root, "p1/project.json").writeText("lixo")
        val l = s.load("p1")!!
        assertEquals("v1", l.project.name); assertTrue(l.recoveredFromBackup)
    }

    @Test fun tampered_content_fails_checksum() {
        val root = tmp.newFolder(); val s = ProjectStore(root)
        s.save(p("A", 1))
        val f = File(root, "p1/project.json")
        f.writeText(f.readText().replace("\"A\"", "\"B\""))
        assertNull(s.load("p1"))
    }

    @Test fun path_traversal_id_is_rejected() {
        val s = ProjectStore(tmp.newFolder())
        assertThrows(IllegalArgumentException::class.java) { s.save(Project("../x", "A", 1, 1)) }
    }

    @Test fun delete_removes_only_project_dir() {
        val root = tmp.newFolder(); val s = ProjectStore(root)
        s.save(p("A", 1)); s.delete("p1")
        assertNull(s.load("p1")); assertTrue(root.exists())
    }
}
